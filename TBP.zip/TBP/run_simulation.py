import math
import subprocess
import traci
import firebase_admin
from firebase_admin import credentials, db

# ——— 1) FETCH V & L from Firebase ———
cred = credentials.Certificate("traffic-management-f3cd5-firebase-adminsdk-fbsvc-7080c55f84.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://traffic-management-f3cd5-default-rtdb.firebaseio.com/"
})
ref = db.reference("traffic_data/signal1")
data = ref.get() or {}
V = max(0, int(data.get("vehicle_count", 0)))
L = max(1, int(data.get("lane_count",    1)))
print(f"  Fetched V={V}, L={L}")

# ——— 2) WRITE nodes.nod.xml ———
with open("nodes.nod.xml", "w") as f:
    f.write("""<nodes>
  <node id="n1" x="0.0" y="0.0" type="priority"/>
  <node id="n2" x="100.0" y="0.0" type="traffic_light"/>
  <node id="n3" x="200.0" y="0.0" type="priority"/>
</nodes>""")

# ——— 3) WRITE edges.edg.xml ———
with open("edges.edg.xml", "w") as f:
    f.write(f"""<edges>
  <edge id="e1" from="n1" to="n2" numLanes="{L}" speed="3.5"/>
  <edge id="e2" from="n2" to="n3" numLanes="{L}" speed="3.5"/>
</edges>""")

# ——— 4) GENERATE network.net.xml ———
subprocess.run([
    "netconvert",
    "-n", "nodes.nod.xml",
    "-e", "edges.edg.xml",
    "-o", "network.net.xml"
], check=True)
print("  network.net.xml generated")

# ——— 5) GENERATE traffic.rou.xml with vehicles placed just before signal ———
spacing = 8.0
rows    = math.ceil(V / L)

with open("traffic.rou.xml", "w") as f:
    f.write("<routes>\n")
    f.write('  <vType id="car" accel="1.0" decel="3.5" length="4" '
            'minGap="0.1" maxSpeed="3.5" guiShape="passenger"/>\n')
    f.write('  <route id="r0" edges="e1 e2"/>\n')

    vid = 0
    for row in range(rows):
        for lane_idx in range(L):
            if vid >= V:
                break
            # Place each vehicle row-wise just before the signal (100 m is signal point)
            pos = 100.0 - ((row + 1) * spacing)
            f.write(
                f'  <vehicle id="veh{vid}" type="car" route="r0" '
                f'depart="0" departLane="{lane_idx}" departPos="{pos}"/>\n'
            )
            vid += 1
        if vid >= V:
            break
    f.write("</routes>\n")

print(f" traffic.rou.xml generated — {vid} vehicles positioned near signal")

# ——— 6) WRITE simulation.sumocfg ———
with open("simulation.sumocfg", "w") as f:
    f.write("""<configuration>
  <input>
    <net-file value="network.net.xml"/>
    <route-files value="traffic.rou.xml"/>
  </input>
  <time>
    <begin value="0"/>
    <end   value="100"/>
  </time>
</configuration>""")
print("  simulation.sumocfg generated")

# ——— 7) RUN SIMULATION WITH RED at t=0, GREEN from t=1 ———
traci.start(["sumo-gui", "-c", "simulation.sumocfg"])
tl_id   = "n2"
g_state = "G" * L
r_state = "r" * L

step = 0
while traci.simulation.getTime() <=(math.ceil(math.ceil(V / L)*3.5)):
    if step == 0:
        traci.trafficlight.setRedYellowGreenState(tl_id, r_state)
    else:
        traci.trafficlight.setRedYellowGreenState(tl_id, g_state)
    traci.simulationStep()
    step += 1
traci.trafficlight.setRedYellowGreenState(tl_id, r_state)
traci.close()
print(" Simulation complete with vehicles crossing intersection.")
